//
//  Na_zdrowieApp.swift
//  Na zdrowie
//
//  Created by Jada on 27/05/21.
//

import SwiftUI

@main
struct Na_zdrowieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
