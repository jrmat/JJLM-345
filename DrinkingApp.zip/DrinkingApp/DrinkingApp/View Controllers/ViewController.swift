//
//  ViewController.swift
//  DrinkingApp
//
//  Created by Mohammed El Saka on 5/10/21.
//  Copyright © 2021 Mohammed El Saka. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

